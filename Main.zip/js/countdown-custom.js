jQuery(document).ready(function() {
        jQuery(function () {
            jQuery('#defaultCountdown').countdown({until: new Date(2018, 2, 16, 8)}); // year, month, date, hour
        });
});		

